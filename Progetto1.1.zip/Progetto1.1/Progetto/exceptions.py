class EmptyResultException(Exception):
    pass

class ResultException(Exception):
    pass
